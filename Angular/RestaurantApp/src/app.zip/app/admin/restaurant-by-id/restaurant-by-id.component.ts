import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurant-by-id',
  templateUrl: './restaurant-by-id.component.html',
  styleUrls: ['./restaurant-by-id.component.css']
})
export class RestaurantByIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
