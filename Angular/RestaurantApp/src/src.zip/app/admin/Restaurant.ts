export interface Restaurant{
    resId: string
    resName: string
    address: string
    email: string
    menu: object
}